package com.props.adsmanager;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.props.adsmanager.Models.PropsAdsManagementModels;
import com.props.adsmanager.connection.API;
import com.props.adsmanager.connection.PROPS_REST_API;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PropsAdsManagement extends LinearLayout {
    private LinearLayout ads_linearlayout;
    private AdView adView;
    private Context context;
    private String adUnitId = "/160553881/props_testt";
    private String targetedAdUnit;
    public static Map<String, String> adsMapping  = new HashMap<>();
    private static boolean isMappingInitialized = false;

    public static void initializeAdmob(Context context) {
        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(@NonNull InitializationStatus initializationStatus) {
                System.out.println("Admob & Adx Initialized");
            }
        });
    }

    private static void requestAdunitData(String apkName) {
        API api = PROPS_REST_API.createAPI();
        Call<List<PropsAdsManagementModels>> cb = api.getAdsPosition(context.getPackageName());
//        try {
//            Response<List<PropsAdsManagementModels>> result = cb.execute();
//            List<PropsAdsManagementModels> data = result.body();
//
//            for (PropsAdsManagementModels model : data) {
//                PropsAdsManagement.adsMapping.put(model.position, model.adUnitID);
//            }
//        } catch (Exception e) {
//            System.out.println("Failed to hit ProPS API");
//        }
        cb.enqueue(new Callback<List<PropsAdsManagementModels>>() {
            @Override
            public void onResponse(Call<List<PropsAdsManagementModels>> call, Response<List<PropsAdsManagementModels>> response) {
                if (response.isSuccessful()) {
                    List<PropsAdsManagementModels> data = response.body();

                    for (PropsAdsManagementModels model : data) {
                        PropsAdsManagement.adsMapping.put(model.position, model.adUnitID);
                    }

                    for(Map.Entry<String, String> entry : adsMapping.entrySet()) {
                        System.out.println("Key: " + entry.getKey() + " | Ad Unit ID: " + entry.getValue());
                    }
                    PropsAdsManagement.isMappingInitialized = true;
                }
            }

            @Override
            public void onFailure(Call<List<PropsAdsManagementModels>> call, Throwable t) {

            }
        });
    }


    public static void initializeAdsMapping(Context context) {
        PropsAdsManagement.requestAdunitData(context.getPackageName());
        PropsAdsManagement.adsMapping.put("default", "ca-app-pub-3940256099942544/6300978111");
    }

    public PropsAdsManagement(Context context) {
        super(context);
        this.context = context;
        initializeAdsManagement(context);
    }

    public PropsAdsManagement(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initializeAdsManagement(context);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.PropsAdsManagement);
        try {
            String getSizes = ta.getString(R.styleable.PropsAdsManagement_adSize);
            String getPositionTargeting = ta.getString(R.styleable.PropsAdsManagement_positionTargeting);

            this.createBanner(getSizes, getPositionTargeting);
        } finally {
            ta.recycle();
        }
        initializeAdsManagement(context);
    }

    private void initializeAdsManagement(Context context) {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        inflater.inflate(R.layout.props_ads_management, this);

        this.ads_linearlayout = findViewById(R.id.ads_linearlayout);

    }

    private LinearLayout createBanner(String sizes, String mapping) {
        AdSize adSize = null;

        if (sizes.equals("BANNER")) {
            adSize = AdSize.BANNER;
        } else if (sizes.equals("LARGE_BANNER")) {
            adSize = AdSize.LARGE_BANNER;
        }  else if (sizes.equals("MEDIUM_RECTANGLE")) {
            adSize = AdSize.MEDIUM_RECTANGLE;
        } else if (sizes.equals("FULL_BANNER")) {
            adSize = AdSize.FULL_BANNER;
        } else if (sizes.equals("LEADERBOARD")){
            adSize = AdSize.LEADERBOARD;
        } else {
            adSize = AdSize.BANNER;
        }
        for(Map.Entry<String, String> entry : adsMapping.entrySet()) {
            System.out.println("Key Admap: " + entry.getKey() + " | Ad Unit ID: " + entry.getValue());
        }

        adView = new AdView(this.context);
        String getMapping = PropsAdsManagement.adsMapping.get(mapping);
        if (getMapping == null) {
            getMapping = this.adUnitId;
        }
        adView.setAdSize(adSize);
        adView.setAdUnitId(getMapping);
        adView.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        this.ads_linearlayout.addView(adView);

        AdRequest adrequest = new AdRequest.Builder().build();
        adView.loadAd(adrequest);
        return this.ads_linearlayout;
    }

    private LinearLayout createBanner(AdSize adSize, String mapping) {
        adView = new AdView(this.context);
        String getMapping = PropsAdsManagement.adsMapping.get(mapping);
        if (getMapping == null) {
            getMapping = this.adUnitId;
        }
        adView.setAdUnitId(adUnitId);
        adView.setAdSize(adSize);
        this.ads_linearlayout.addView(adView);
        return this.ads_linearlayout;
    }

    private LinearLayout createCustomSizedBanner(int width, int height, String mapping) {
        AdSize adSize = new AdSize(width, height);
        adView = new AdView(this.context);
        String getMapping = PropsAdsManagement.adsMapping.get(mapping);
        if (getMapping == null) {
            getMapping = this.adUnitId;
        }
        adView.setAdUnitId(adUnitId);
        this.ads_linearlayout.addView(adView);
        return this.ads_linearlayout;
    }
}
