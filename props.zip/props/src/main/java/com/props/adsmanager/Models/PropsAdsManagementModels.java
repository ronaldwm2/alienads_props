package com.props.adsmanager.Models;

import java.io.Serializable;

public class PropsAdsManagementModels implements Serializable {
    public String position = "";
    public String partner = "";
    public String adUnitID = "";
}
